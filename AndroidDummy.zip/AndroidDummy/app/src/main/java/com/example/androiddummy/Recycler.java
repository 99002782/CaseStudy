package com.example.androiddummy;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class Recycler extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler);
        MyListData[] myListData = new MyListData[] {
                new MyListData("Chicken Biryani"),
                new MyListData("Chicken 65"),
                new MyListData("Dum Biryani"),
                new MyListData("Statter"),
                new MyListData("Rumali Roti"),
                new MyListData("Pizza"),
                new MyListData("Panner Manchuria"),

        };

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recycleview);
        MyAdapter adapter = new MyAdapter(myListData);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }
}
