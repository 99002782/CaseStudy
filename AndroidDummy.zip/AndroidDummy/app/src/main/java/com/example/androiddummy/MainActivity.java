package com.example.androiddummy;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private static final String TAG =MainActivity.class.getSimpleName() ;
    public static final String MYPREFS = "myprefs";
    public static final String NAMEKEY = "namekey";
    public static final String PWDKEY = "pwdkey";
    EditText editn,editp;
    Button remember;

Button result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editn =  findViewById(R.id.editname);
        editp = findViewById(R.id.editpass);
        remember = findViewById(R.id.checkbox);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i(TAG,"onpause");
        saveData();
    }
//
    private void saveData() {
        Log.i(TAG,"saveData");

        //get the data from the edittext
        String name = editn.getText().toString();
        String pwd = editp.getText().toString();
        //create a file names myprefs
        SharedPreferences preferences = getSharedPreferences(MYPREFS,MODE_PRIVATE);
        //open the file
        SharedPreferences.Editor editor = preferences.edit();
        //write to the file
        editor.putString(NAMEKEY,name);
        editor.putString(PWDKEY,pwd);
        //save the file
        editor.apply();
    }
    protected void onResume() {
        super.onResume();
        Log.i(TAG,"onresume");
        restoreData();
    }
    private void restoreData(){
        Log.i(TAG,"restoreData");

        //open the file
        SharedPreferences preferences = getSharedPreferences(MYPREFS,MODE_PRIVATE);
        //read the file
        String name = preferences.getString(NAMEKEY,"");
        String pwd = preferences.getString(PWDKEY,"");
        //set the data in edittexts
        editn.setText(name);
        editp.setText(pwd);
    }
//    public void show(View view) {
//        String name = .getText().toString();
//        String password = editPassword.getText().toString();
//        result.setText("Name:\t" + name);
//    }

    public void check(View view) {
        if(editn.getText().toString().equals("android") && editp.getText().toString().equals("android123")) {
            //Toast.makeText(getApplicationContext(), "Login successful", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(MainActivity.this, Recycler.class);
             startActivity(intent);
        }
    else
        {
            Toast.makeText(getApplicationContext(), "Login Unsuccessful", Toast.LENGTH_LONG).show();
        }
    }
}